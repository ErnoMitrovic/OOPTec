#include "cMatFrac.h"

int main(){
  MatFrac * m1 = new MatFrac("./mat1.txt"),
  * m2 = new MatFrac("./mat2.txt");
  m1 -> printFracs();
  std::cout << " + \n";
  m2->printFracs();
  std::cout << " = \n";
  std::cout << "--- See file generated ---\n";
}