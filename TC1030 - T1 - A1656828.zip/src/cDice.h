#include <random>
#include <ctime>

class Dice
{
private:
    int value;
public:
    Dice();
    ~Dice();
    int roll();
};
