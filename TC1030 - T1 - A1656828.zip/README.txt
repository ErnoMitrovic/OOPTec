Instruction to compile the program:
g++ ./src/*.cpp -o main; ./main
The program asks if the user wants to print the board, and then it starts the game.

It includes the flow diagram of the design.